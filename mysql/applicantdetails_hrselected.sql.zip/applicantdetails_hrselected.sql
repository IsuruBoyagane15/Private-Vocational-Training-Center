-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 17, 2018 at 03:01 AM
-- Server version: 10.1.29-MariaDB
-- PHP Version: 7.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `applicantdetails_hrselected`
--

-- --------------------------------------------------------

--
-- Table structure for table `selected_lecturer_details`
--

CREATE TABLE `selected_lecturer_details` (
  `id` int(9) UNSIGNED NOT NULL,
  `course` varchar(50) NOT NULL,
  `name_with_initials` varchar(50) NOT NULL,
  `fullname` varchar(100) NOT NULL,
  `medium` varchar(20) NOT NULL,
  `address` varchar(200) NOT NULL,
  `nic` varchar(10) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `date_of_birth` varchar(100) NOT NULL,
  `age` varchar(3) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `home` varchar(12) NOT NULL,
  `email` varchar(30) NOT NULL,
  `year_of_ol` varchar(100) NOT NULL,
  `year_of_al` varchar(100) NOT NULL,
  `index_al` varchar(100) NOT NULL,
  `stream` varchar(10) NOT NULL,
  `degree` varchar(100) NOT NULL,
  `applied_date` datetime NOT NULL,
  `selected_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `selected_lecturer_details`
--

INSERT INTO `selected_lecturer_details` (`id`, `course`, `name_with_initials`, `fullname`, `medium`, `address`, `nic`, `gender`, `date_of_birth`, `age`, `mobile`, `home`, `email`, `year_of_ol`, `year_of_al`, `index_al`, `stream`, `degree`, `applied_date`, `selected_date`) VALUES
(3, 'National Certificate - Automobile Mechanic', 'M. Perera', 'Mahaname Perera', 'English', 'No 36, Sama Mawatha', '123456789v', 'Male', '1980-10-10', '38', '0711212123', '0111212123', 'mahanamma@gmail.com', '2010', '2012', '123456', 'Physical S', 'Cima', '2018-07-09 12:50:57', '2018-07-09 07:54:25');

-- --------------------------------------------------------

--
-- Table structure for table `selected_student_details`
--

CREATE TABLE `selected_student_details` (
  `id` int(9) UNSIGNED NOT NULL,
  `course` varchar(30) NOT NULL,
  `name_with_initials` varchar(30) NOT NULL,
  `fullname` varchar(30) NOT NULL,
  `medium` varchar(15) NOT NULL,
  `address` varchar(50) NOT NULL,
  `nic` varchar(10) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `date_of_birth` date NOT NULL,
  `age` int(3) NOT NULL,
  `mobile` varchar(12) NOT NULL,
  `home` varchar(12) NOT NULL,
  `email` varchar(50) NOT NULL,
  `year_of_ol` varchar(4) NOT NULL,
  `index_ol` varchar(10) NOT NULL,
  `maths` varchar(1) NOT NULL,
  `english` varchar(1) NOT NULL,
  `science` varchar(1) NOT NULL,
  `year_of_al` varchar(4) NOT NULL,
  `index_al` varchar(10) NOT NULL,
  `stream` varchar(20) NOT NULL,
  `applied_date` datetime NOT NULL,
  `selected_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `selected_student_details`
--

INSERT INTO `selected_student_details` (`id`, `course`, `name_with_initials`, `fullname`, `medium`, `address`, `nic`, `gender`, `date_of_birth`, `age`, `mobile`, `home`, `email`, `year_of_ol`, `index_ol`, `maths`, `english`, `science`, `year_of_al`, `index_al`, `stream`, `applied_date`, `selected_date`) VALUES
(4, 'National Certificate - Plumber', 'A. Perera', 'Anjelo Mendis', 'Sinhala', 'No 18, Katubedda.', '123456789v', 'male', '1993-12-14', 25, '0715151515', '0111515159', 'anje@gamil.com', '2007', '201455', 'B', 'A', 'A', '2011', '524898', 'physical', '2018-07-09 11:53:15', '2018-07-09 07:54:37');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `selected_lecturer_details`
--
ALTER TABLE `selected_lecturer_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `selected_student_details`
--
ALTER TABLE `selected_student_details`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `selected_lecturer_details`
--
ALTER TABLE `selected_lecturer_details`
  MODIFY `id` int(9) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `selected_student_details`
--
ALTER TABLE `selected_student_details`
  MODIFY `id` int(9) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
