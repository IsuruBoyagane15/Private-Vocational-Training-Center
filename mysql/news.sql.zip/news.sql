-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 17, 2018 at 03:05 AM
-- Server version: 10.1.29-MariaDB
-- PHP Version: 7.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `news`
--

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int(6) NOT NULL,
  `id_key` varchar(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `file_name` varchar(200) NOT NULL,
  `file_path` varchar(300) NOT NULL,
  `description` varchar(5000) DEFAULT NULL,
  `added_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `remove_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `id_key`, `name`, `file_name`, `file_path`, `description`, `added_date`, `remove_date`) VALUES
(5, 'hr', 'Motivation', '0b7dd5e200ade91521d0edb0ce8d3445.jpg', 'File Upload/News/0b7dd5e200ade91521d0edb0ce8d3445.jpg', 'kjdfshak dfd fajdf adf df adf ', '2018-07-08 22:00:11', '2019-01-01 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `temporary_news`
--

CREATE TABLE `temporary_news` (
  `id` int(6) NOT NULL,
  `id_key` varchar(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `file_name` varchar(200) DEFAULT NULL,
  `file_path` varchar(300) DEFAULT NULL,
  `description` varchar(5000) DEFAULT NULL,
  `added_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `remove_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `temporary_news`
--

INSERT INTO `temporary_news` (`id`, `id_key`, `name`, `file_name`, `file_path`, `description`, `added_date`, `remove_date`) VALUES
(6, 'hr', 'achivemnts', 'Screenshot (16).png', 'File Upload/News/Screenshot (16).png', 'Empowering Sri Lankans to realize their life goals through affordable yet best-in-class banking solutions in its steadfast journey of over 77 years, BOC has always gone that extra mile to add value to the Sri Lankan banking industry.', '2018-07-09 06:27:26', '2019-11-01 00:00:00'),
(7, 'hr', 'uhn', 'WhatsApp Image 2018-07-06 at 20.05.45.jpeg', 'File Upload/News/WhatsApp Image 2018-07-06 at 20.05.45.jpeg', 'ghb', '2018-07-09 07:53:54', '2018-10-01 00:00:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `temporary_news`
--
ALTER TABLE `temporary_news`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `temporary_news`
--
ALTER TABLE `temporary_news`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
