-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 17, 2018 at 03:05 AM
-- Server version: 10.1.29-MariaDB
-- PHP Version: 7.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `course_info`
--

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `course_name` varchar(100) NOT NULL,
  `student_count` int(4) UNSIGNED NOT NULL,
  `duration` int(2) UNSIGNED NOT NULL,
  `trade` varchar(50) NOT NULL,
  `course_type` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL,
  `accredit_level` varchar(50) NOT NULL,
  `medium` varchar(50) NOT NULL,
  `required_qualification` varchar(50) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `id` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`course_name`, `student_count`, `duration`, `trade`, `course_type`, `type`, `accredit_level`, `medium`, `required_qualification`, `description`, `id`) VALUES
('National Certificate - Baker', 150, 6, 'Food Technology', 'full', 'NVQ', '2', 'sinhala', 'Pass Year 9', 'This course is about.....', 78),
('sasd', 100, 12, 'Agriculture Plantation and Livestock', 'part', 'NVQ', '1', 'english', 'kjhsdfkjs', 'jhdkjad', 81);

-- --------------------------------------------------------

--
-- Table structure for table `modules`
--

CREATE TABLE `modules` (
  `module_name` varchar(100) NOT NULL,
  `description` varchar(500) NOT NULL,
  `lecturer` varchar(100) NOT NULL,
  `course_id` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `modules`
--

INSERT INTO `modules` (`module_name`, `description`, `lecturer`, `course_id`) VALUES
('module l', 'This is module l. This is about...', '000091L', 78),
('module m', 'This is module m. This is about..', '000092L', 78),
('module n', 'This is module n. This is about..', '000093L', 78);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `modules`
--
ALTER TABLE `modules`
  ADD PRIMARY KEY (`description`),
  ADD KEY `course_id` (`course_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=82;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `modules`
--
ALTER TABLE `modules`
  ADD CONSTRAINT `modules_ibfk_1` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`),
  ADD CONSTRAINT `modules_ibfk_2` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
