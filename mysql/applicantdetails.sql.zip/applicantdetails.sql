-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 17, 2018 at 03:00 AM
-- Server version: 10.1.29-MariaDB
-- PHP Version: 7.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `applicantdetails`
--

-- --------------------------------------------------------

--
-- Table structure for table `lecturer_details`
--

CREATE TABLE `lecturer_details` (
  `id` int(9) NOT NULL,
  `course` varchar(50) NOT NULL,
  `name_with_initials` varchar(50) NOT NULL,
  `fullname` varchar(100) NOT NULL,
  `address` varchar(200) NOT NULL,
  `nic` varchar(10) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `home` varchar(12) NOT NULL,
  `email` varchar(30) NOT NULL,
  `date_of_birth` varchar(100) NOT NULL,
  `age` varchar(3) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `year_of_ol` varchar(100) NOT NULL,
  `year_of_al` varchar(100) NOT NULL,
  `index_al` int(100) NOT NULL,
  `stream` varchar(10) NOT NULL,
  `degree` varchar(100) NOT NULL,
  `applied_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `medium` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lecturer_details`
--

INSERT INTO `lecturer_details` (`id`, `course`, `name_with_initials`, `fullname`, `address`, `nic`, `mobile`, `home`, `email`, `date_of_birth`, `age`, `gender`, `year_of_ol`, `year_of_al`, `index_al`, `stream`, `degree`, `applied_date`, `medium`) VALUES
(8, 'National Certificate - Automobile Mechanic', 'm.l.p.ghgv', 'ffrtff', 'tfrtfftf', '965642874v', '0745869587', '0112584758', 'ytfyf@fcf', '1999-07-01', '19', 'Male', '2017', '2017', 123456, 'Physical S', 'ftyffdrfytf', '2018-07-09 07:50:45', 'English'),
(9, 'National Certificate - Automobile Mechanic', 'fgfgf', 'gfgfg', 'bfgfgf', '88888888v', '7777777777', '7777777777', 'gg@ee', '2018-07-03', '0', 'Male', '2017', '2017', 444444, 'Physical S', '', '2018-07-09 07:52:42', 'English');

-- --------------------------------------------------------

--
-- Table structure for table `student_details`
--

CREATE TABLE `student_details` (
  `id` int(9) NOT NULL,
  `course` varchar(30) NOT NULL,
  `name_with_initials` varchar(30) NOT NULL,
  `fullname` varchar(30) NOT NULL,
  `medium` varchar(15) NOT NULL,
  `address` varchar(50) NOT NULL,
  `nic` varchar(10) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `date_of_birth` varchar(12) NOT NULL,
  `age` int(3) NOT NULL,
  `mobile` varchar(12) NOT NULL,
  `home` varchar(12) NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `applied_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `year_of_ol` varchar(4) NOT NULL,
  `index_ol` varchar(10) NOT NULL,
  `maths` varchar(1) NOT NULL,
  `english` varchar(1) NOT NULL,
  `science` varchar(1) NOT NULL,
  `year_of_al` varchar(4) NOT NULL,
  `index_al` varchar(10) NOT NULL,
  `stream` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `lecturer_details`
--
ALTER TABLE `lecturer_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `student_details`
--
ALTER TABLE `student_details`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `lecturer_details`
--
ALTER TABLE `lecturer_details`
  MODIFY `id` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `student_details`
--
ALTER TABLE `student_details`
  MODIFY `id` int(9) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
