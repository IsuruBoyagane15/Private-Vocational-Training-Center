-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 17, 2018 at 03:06 AM
-- Server version: 10.1.29-MariaDB
-- PHP Version: 7.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `students`
--

-- --------------------------------------------------------

--
-- Table structure for table `profile_pics`
--

CREATE TABLE `profile_pics` (
  `filename` varchar(1000) NOT NULL,
  `index_number` varchar(10) NOT NULL,
  `filepath` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `profile_pics`
--

INSERT INTO `profile_pics` (`filename`, `index_number`, `filepath`) VALUES
('images.jpg', '180002', 'File Upload/profile_pics/180002/images.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `student_info`
--

CREATE TABLE `student_info` (
  `student_index` varchar(32) NOT NULL,
  `course_id` varchar(32) NOT NULL,
  `nic` int(10) NOT NULL,
  `initial_name` varchar(255) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `medium` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `birthday` date NOT NULL,
  `age` int(11) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `home` varchar(10) NOT NULL,
  `email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_info`
--

INSERT INTO `student_info` (`student_index`, `course_id`, `nic`, `initial_name`, `fullname`, `medium`, `address`, `gender`, `birthday`, `age`, `mobile`, `home`, `email`) VALUES
('180001', 'c72', 901542263, 'K Bandara', 'Kusal Bandara', 'English', 'No 45, Katubedda', 'Male', '1990-05-07', 28, '0774589654', '0115478965', 'kusal@gmail.com'),
('180002', 'c72', 956856582, 'Y. bandara', 'Yasas bandara', 'English', 'No', 'Male', '1995-02-07', 23, '0711515159', '0111515159', 'yasas@gmail.com'),
('180003', 'National Certificate - Plumber', 123456789, 'A. Mendis', 'Ajantha Mendis', 'Sinhala', 'No 12, Katubedda.', 'male', '1993-12-14', 25, '0715151515', '0111515159', 'aja@gamil.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `student_info`
--
ALTER TABLE `student_info`
  ADD PRIMARY KEY (`student_index`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
