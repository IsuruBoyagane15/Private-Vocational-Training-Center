-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 17, 2018 at 03:04 AM
-- Server version: 10.1.29-MariaDB
-- PHP Version: 7.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `courses_details`
--

-- --------------------------------------------------------

--
-- Table structure for table `c70`
--

CREATE TABLE `c70` (
  `modules` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `c70`
--

INSERT INTO `c70` (`modules`) VALUES
('70m1');

-- --------------------------------------------------------

--
-- Table structure for table `c71`
--

CREATE TABLE `c71` (
  `modules` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `c71`
--

INSERT INTO `c71` (`modules`) VALUES
('71m1'),
('71m2');

-- --------------------------------------------------------

--
-- Table structure for table `c72`
--

CREATE TABLE `c72` (
  `modules` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `c72`
--

INSERT INTO `c72` (`modules`) VALUES
('72m1'),
('72m2'),
('72m3');

-- --------------------------------------------------------

--
-- Table structure for table `c74`
--

CREATE TABLE `c74` (
  `modules` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `c74`
--

INSERT INTO `c74` (`modules`) VALUES
('74m1');

-- --------------------------------------------------------

--
-- Table structure for table `c75`
--

CREATE TABLE `c75` (
  `modules` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `c75`
--

INSERT INTO `c75` (`modules`) VALUES
('75m1'),
('75m2');

-- --------------------------------------------------------

--
-- Table structure for table `c76`
--

CREATE TABLE `c76` (
  `modules` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `c76`
--

INSERT INTO `c76` (`modules`) VALUES
('76m1'),
('76m2'),
('76m3');

-- --------------------------------------------------------

--
-- Table structure for table `c77`
--

CREATE TABLE `c77` (
  `modules` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `c77`
--

INSERT INTO `c77` (`modules`) VALUES
('77m1'),
('77m2'),
('77m3');

-- --------------------------------------------------------

--
-- Table structure for table `course_details`
--

CREATE TABLE `course_details` (
  `course_id` varchar(32) NOT NULL,
  `trade` varchar(255) NOT NULL,
  `course_name` varchar(255) NOT NULL,
  `course_type` varchar(10) NOT NULL,
  `type` varchar(10) NOT NULL,
  `accredit_level` varchar(255) NOT NULL,
  `duration` int(2) NOT NULL,
  `medium` varchar(255) NOT NULL,
  `required_qualification` varchar(255) NOT NULL,
  `student_count` int(4) NOT NULL,
  `description` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course_details`
--

INSERT INTO `course_details` (`course_id`, `trade`, `course_name`, `course_type`, `type`, `accredit_level`, `duration`, `medium`, `required_qualification`, `student_count`, `description`) VALUES
('c70', 'Automobile repair and maintainance', 'National Certificate - Automobile Mechanic', 'full', 'NVQ', '3', 6, 'english', ' PASS YEAR 9', 200, 'Thos course is about....'),
('c71', 'Agriculture Plantation and Livestock', 'National Certificate - Plant Nursery Development A', 'full', 'NVQ', '3', 3, 'english', ' pass year 9', 100, 'adsfadsf adfadfaf'),
('c72', 'Building and Construction', 'National Certificate - Plumber', 'full', 'NVQ', 'certificate', 6, 'sinhala', ' pass year 9', 250, 'this course is about......'),
('c74', 'Electrical and Electronic and Telecommunication', 'National Certificate - Electrician', 'full', 'NVQ', '5', 11, 'english', ' Sat for G.C.E.(O/L)', 300, 'This course is about....'),
('c75', 'Electrical and Electronic and Telecommunication', 'Electrical Motor Controller(Part Time)', 'part', 'NVQ', '3', 6, 'english', ' Sat for G.C.E.(O/L)', 100, 'This course is about......'),
('c76', 'Gem and jewellary', 'National Certificate - Jewellery Stone Setter', 'full', 'NVQ', '3', 6, 'english', ' Pass Year 9', 50, 'This course is about....'),
('c77', 'Hotel and Tourism', 'National Certificate - Room Attendant', 'full', 'NVQ', '3', 4, 'sinhala', ' pass year 9', 200, 'This course is about...');

-- --------------------------------------------------------

--
-- Table structure for table `module_details`
--

CREATE TABLE `module_details` (
  `module_id` varchar(255) NOT NULL,
  `module_name` varchar(255) NOT NULL,
  `no_of_students` int(11) NOT NULL,
  `lecturer_id` varchar(55) NOT NULL,
  `module_description` varchar(10000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `module_details`
--

INSERT INTO `module_details` (`module_id`, `module_name`, `no_of_students`, `lecturer_id`, `module_description`) VALUES
('70m1', 'module3', 200, '000092L', 'This i'),
('71m1', 'mod1', 100, '000091L', 'adsfadf fadfadfadsf'),
('71m2', 'mod2', 100, '000092L', 'dafa dfadf'),
('72m1', 'module1', 250, '000091L', 'This is module1. This is about...'),
('72m2', 'module2', 250, '000091L', 'This is module2. This is about...'),
('72m3', 'module3', 250, '000093L', 'This is module3. This is about...'),
('74m1', 'module1', 300, '000091L', 'This is module 1. This is about....'),
('75m1', 'module1', 100, '000092L', 'This is module 1. This is about...'),
('75m2', 'module2', 100, '000093L', 'This module is about....'),
('76m1', 'module A', 50, '000092L', 'This is module A. This is about....'),
('76m2', 'module B', 50, '000091L', 'This is module B. This is about....'),
('76m3', 'module C', 50, '000093L', 'This is module c. This is about....'),
('77m1', 'Module P', 200, '000091L', 'This is module p. This is about...'),
('77m2', 'module q', 200, '000092L', 'This is module q. This is about...'),
('77m3', 'module r', 200, '000093L', 'This is module r. This is about...');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `course_details`
--
ALTER TABLE `course_details`
  ADD PRIMARY KEY (`course_id`);

--
-- Indexes for table `module_details`
--
ALTER TABLE `module_details`
  ADD UNIQUE KEY `module_id` (`module_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
