-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 17, 2018 at 03:03 AM
-- Server version: 10.1.29-MariaDB
-- PHP Version: 7.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `configdata`
--

-- --------------------------------------------------------

--
-- Table structure for table `config_createassignment`
--

CREATE TABLE `config_createassignment` (
  `id` int(11) NOT NULL,
  `tableName` varchar(100) NOT NULL,
  `module` varchar(100) NOT NULL,
  `assignment_name` varchar(100) NOT NULL,
  `deadline` datetime DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `description` varchar(1000) NOT NULL,
  `no_of_attempts` int(1) NOT NULL DEFAULT '1',
  `late_allowed` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `config_createassignment`
--

INSERT INTO `config_createassignment` (`id`, `tableName`, `module`, `assignment_name`, `deadline`, `is_deleted`, `description`, `no_of_attempts`, `late_allowed`) VALUES
(0, 'assignment0', ' mod1', 'assignment 01', '0000-00-00 00:00:00', 0, '', 1, 0),
(1, 'assignment1', 'module1', 'assignment test', '0000-00-00 00:00:00', 0, '', 1, 0),
(2, 'assignment2', 'module1', 'assignment os', '2018-09-01 01:00:00', 0, 'This set of Operating System Multiple Choice Questions & Answers focuses on â€œVirtual Memory â€“ Allocation of Framesâ€.', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `config_lectureuploads`
--

CREATE TABLE `config_lectureuploads` (
  `id` int(11) NOT NULL,
  `filename` varchar(200) NOT NULL,
  `module` varchar(200) NOT NULL,
  `file_path` varchar(200) NOT NULL,
  `module_code` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `config_lectureuploads`
--

INSERT INTO `config_lectureuploads` (`id`, `filename`, `module`, `file_path`, `module_code`) VALUES
(2, 'C TutorialsPoint.pdf', 'module1', 'File Upload/Lecture Notes/module1/C TutorialsPoint.pdf', ''),
(3, 'C++ TutorialsPoint.pdf', 'module1', 'File Upload/Lecture Notes/module1/C++ TutorialsPoint.pdf', ''),
(4, 'WhatsApp Image 2018-07-06 at 20.05.45.jpeg', ' module1 ', 'File Upload/Lecture Notes/module1/WhatsApp Image 2018-07-06 at 20.05.45.jpeg', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `config_createassignment`
--
ALTER TABLE `config_createassignment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `config_lectureuploads`
--
ALTER TABLE `config_lectureuploads`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `config_lectureuploads`
--
ALTER TABLE `config_lectureuploads`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
