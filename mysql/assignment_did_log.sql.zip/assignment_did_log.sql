-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 17, 2018 at 03:02 AM
-- Server version: 10.1.29-MariaDB
-- PHP Version: 7.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `assignment_did_log`
--

-- --------------------------------------------------------

--
-- Table structure for table `assignment0`
--

CREATE TABLE `assignment0` (
  `student_id` int(7) NOT NULL,
  `student_name` varchar(200) DEFAULT NULL,
  `total_questions` int(3) DEFAULT NULL,
  `correct_answers` int(3) DEFAULT NULL,
  `marks` varchar(3) DEFAULT NULL,
  `timetaken` varchar(8) DEFAULT NULL,
  `is_late` tinyint(1) DEFAULT NULL,
  `comments` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `assignment1`
--

CREATE TABLE `assignment1` (
  `student_id` int(7) NOT NULL,
  `student_name` varchar(200) DEFAULT NULL,
  `total_questions` int(3) DEFAULT NULL,
  `correct_answers` int(3) DEFAULT NULL,
  `marks` varchar(3) DEFAULT NULL,
  `timetaken` varchar(8) DEFAULT NULL,
  `is_late` tinyint(1) DEFAULT NULL,
  `comments` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `assignment2`
--

CREATE TABLE `assignment2` (
  `student_id` int(7) NOT NULL,
  `student_name` varchar(200) DEFAULT NULL,
  `total_questions` int(3) DEFAULT NULL,
  `correct_answers` int(3) DEFAULT NULL,
  `marks` varchar(3) DEFAULT NULL,
  `timetaken` varchar(8) DEFAULT NULL,
  `is_late` tinyint(1) DEFAULT NULL,
  `comments` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `assignment0`
--
ALTER TABLE `assignment0`
  ADD PRIMARY KEY (`student_id`);

--
-- Indexes for table `assignment1`
--
ALTER TABLE `assignment1`
  ADD PRIMARY KEY (`student_id`);

--
-- Indexes for table `assignment2`
--
ALTER TABLE `assignment2`
  ADD PRIMARY KEY (`student_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
