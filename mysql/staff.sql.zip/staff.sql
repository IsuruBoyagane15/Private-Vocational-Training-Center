-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 17, 2018 at 03:05 AM
-- Server version: 10.1.29-MariaDB
-- PHP Version: 7.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `staff`
--

-- --------------------------------------------------------

--
-- Table structure for table `profile_pics`
--

CREATE TABLE `profile_pics` (
  `filename` varchar(1000) NOT NULL,
  `index_number` varchar(10) NOT NULL,
  `filepath` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `profile_pics`
--

INSERT INTO `profile_pics` (`filename`, `index_number`, `filepath`) VALUES
('04fd5eb2893f1852c76efa864f2e11b9.jpg', '000002D', 'File Upload/profile_pics/000002D/04fd5eb2893f1852c76efa864f2e11b9.jpg'),
('9046aafc18a68cfb40d6868e2d44befc.jpg', '000001H', 'File Upload/profile_pics/000001H/9046aafc18a68cfb40d6868e2d44befc.jpg'),
('gTrYV.png', '000091L', 'File Upload/profile_pics/000091L/gTrYV.png');

-- --------------------------------------------------------

--
-- Table structure for table `staff_details`
--

CREATE TABLE `staff_details` (
  `staff_id` varchar(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `course` varchar(50) NOT NULL,
  `address` varchar(500) NOT NULL,
  `nic` varchar(10) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `date_of_birth` varchar(15) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `selected_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staff_details`
--

INSERT INTO `staff_details` (`staff_id`, `name`, `course`, `address`, `nic`, `gender`, `date_of_birth`, `mobile`, `email`, `selected_date`) VALUES
('000002L', 'L.G. Gunathilake', 'National Certificate - Plant Nursery Development A', 'No 21, suhada mawath', '965874123v', 'Male', '1996-10-07', '0771212123', 'lahiru@gmail.com', '2018-07-09 07:21:17'),
('000091L', 'Mr. Perera', 'National Certificate - Plumber', 'No87, Katubedda Rd', '825496402v', 'Male', '1977-06-08', '7751277905', 'kamal@gmail.com', '2018-07-09 00:33:04'),
('000092L', 'Mr. S Chandrasiri.', 'National Certificate - Automobile Electrician', 'No. 96, Jaya Mawatha', '123456799v', 'Male', '1998-02-03', '1231231232', 'saman@gmail.com', '2018-07-09 01:17:50'),
('000093L', 'Mr. G. Kuamara', 'National Certificate - Automobile Electrician', 'No.63, Wijethunga Mawatha.', '362514789v', 'Male', '2007-03-06', '1234567894', 'gihan@gmail.com', '2018-07-09 01:18:58');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `staff_details`
--
ALTER TABLE `staff_details`
  ADD PRIMARY KEY (`staff_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
